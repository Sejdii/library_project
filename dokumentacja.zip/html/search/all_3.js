var searchData=
[
  ['database_5fpath_19',['DATABASE_PATH',['../dbmanager_8h.html#a5da5effd84a5c7503eb4b9b0ed9383cf',1,'dbmanager.h']]],
  ['dbmanager_20',['DBManager',['../class_d_b_manager.html',1,'DBManager'],['../class_d_b_manager.html#a4b82f81f5f5f4892b31c46cb0c60a766',1,'DBManager::DBManager()']]],
  ['dbmanager_2eh_21',['dbmanager.h',['../dbmanager_8h.html',1,'']]]
];
