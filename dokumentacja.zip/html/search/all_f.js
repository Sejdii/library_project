var searchData=
[
  ['validate_85',['validate',['../class_address.html#a27bb305b31f87c2662f4e7d0c12a3040',1,'Address::validate()'],['../class_author.html#a87d2d478a7950c7cc7a10d9fafc2885b',1,'Author::validate()'],['../class_book.html#a5aead56f62844497e951fc8421057f5e',1,'Book::validate()'],['../class_client.html#a981f23fa4550b321ca3ef4aac1d679b9',1,'Client::validate()'],['../class_publisher.html#a939e4b4cd35a90d9d9415f974011742e',1,'Publisher::validate()'],['../class_rent.html#a029895ed79c7d1c18df34052bac09622',1,'Rent::validate()'],['../class_table.html#adbfac02e309231605421e39d3dc917da',1,'Table::validate()'],['../class_user.html#a48113d0877f7d3e3bb66613c34c021cf',1,'User::validate()'],['../class_worker.html#a8982f914912fb0cc970c7e7d09d50dd9',1,'Worker::validate()']]],
  ['verify_86',['verify',['../class_user.html#ac44a003f17cc4c35e1ab51bf63ccee97',1,'User']]]
];
