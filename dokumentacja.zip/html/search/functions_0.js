var searchData=
[
  ['address_123',['Address',['../class_address.html#a2a369738a668f40beca72a0027d4e1d6',1,'Address']]],
  ['author_124',['Author',['../class_author.html#accb0f767f1b7bf26f9b9720ca1cf8269',1,'Author']]]
];
