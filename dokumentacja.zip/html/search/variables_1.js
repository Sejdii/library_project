var searchData=
[
  ['database_5fpath_195',['DATABASE_PATH',['../dbmanager_8h.html#a5da5effd84a5c7503eb4b9b0ed9383cf',1,'dbmanager.h']]]
];
