var searchData=
[
  ['dbmanager_2eh_106',['dbmanager.h',['../dbmanager_8h.html',1,'']]]
];
