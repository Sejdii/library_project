var searchData=
[
  ['address_93',['Address',['../class_address.html',1,'']]],
  ['author_94',['Author',['../class_author.html',1,'']]]
];
