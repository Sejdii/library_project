var searchData=
[
  ['address_87',['Address',['../class_address.html',1,'']]],
  ['author_88',['Author',['../class_author.html',1,'']]]
];
