var searchData=
[
  ['mainwindow_43',['MainWindow',['../class_main_window.html',1,'MainWindow'],['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2eh_44',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['make_5fconnection_5fauthor_45',['make_connection_author',['../class_book.html#a4cb26f65c22207a780fdaa1feb7c1212',1,'Book']]]
];
