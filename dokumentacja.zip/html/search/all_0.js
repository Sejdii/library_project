var searchData=
[
  ['account_5fclient_0',['ACCOUNT_CLIENT',['../user_8h.html#ab6f77f73558458b038e7bacfd9e4bb46',1,'user.h']]],
  ['account_5fworker_1',['ACCOUNT_WORKER',['../user_8h.html#a22465e41658370828c1d18abedfa8cd6',1,'user.h']]],
  ['address_2',['Address',['../class_address.html',1,'Address'],['../class_address.html#a2a369738a668f40beca72a0027d4e1d6',1,'Address::Address()']]],
  ['address_2eh_3',['address.h',['../address_8h.html',1,'']]],
  ['author_4',['Author',['../class_author.html',1,'Author'],['../class_author.html#accb0f767f1b7bf26f9b9720ca1cf8269',1,'Author::Author()']]],
  ['author_2eh_5',['author.h',['../author_8h.html',1,'']]]
];
