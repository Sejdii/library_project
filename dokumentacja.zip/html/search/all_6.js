var searchData=
[
  ['get_5fcompleter_5flist_26',['get_completer_list',['../class_author.html#a1cb712bf326828773ae6488e5e280b15',1,'Author::get_completer_list()'],['../class_book.html#a8654a52b5b3d234687efb97e3350927a',1,'Book::get_completer_list()'],['../class_client.html#a4c0a61f756c911814704acb609719c2b',1,'Client::get_completer_list()'],['../class_publisher.html#a5c83b4c8580ee8c4d3d554b248d983df',1,'Publisher::get_completer_list()']]],
  ['get_5fdatabase_27',['get_database',['../class_d_b_manager.html#a1c5ebd0bbe9e8fda0e2df2ac756a28bc',1,'DBManager']]],
  ['get_5fid_28',['get_id',['../class_author.html#aef0a25b232d297b7a4d524f067852ab2',1,'Author']]],
  ['get_5fid_5fpublisher_29',['get_id_publisher',['../class_book.html#af1aa9f1fa886550c9558971bffd4fc19',1,'Book']]],
  ['get_5fsearch_5fresult_30',['get_search_result',['../class_client_window.html#a019a1dce43304ed826a53d56bc621018',1,'ClientWindow']]],
  ['getid_31',['getID',['../class_address.html#ad6c4de9728f8a2c45af7c1721e5321c9',1,'Address::getID()'],['../class_user.html#abaee3df5fe4cffe795b58fcdd7d907e3',1,'User::getID()']]],
  ['getlogin_32',['getLogin',['../class_user.html#ae045d8e4f6f43b2b580d3bfbbd3b5778',1,'User']]],
  ['getname_33',['getName',['../class_worker.html#a5b877f8bdd8c54653dc67b1e4ab9ed5a',1,'Worker']]],
  ['getpassword_34',['getPassword',['../class_user.html#a96d673c7c62ecdfdd4c509db8350262d',1,'User']]],
  ['getsearchbox_35',['getSearchBox',['../class_client_window.html#ad60b06edb021bbb1fd176817bb56c910',1,'ClientWindow::getSearchBox()'],['../class_worker_window.html#ad5985a0530ceb75acc393c50ba8fe68b',1,'WorkerWindow::getSearchBox()']]],
  ['gettype_36',['getType',['../class_worker.html#a87fb7e3add61757615eb6752bcad17d6',1,'Worker']]],
  ['gettypename_37',['getTypeName',['../class_user.html#a2bb380862e89ac4f72a4c3596dcf64d1',1,'User']]]
];
