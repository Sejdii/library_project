var searchData=
[
  ['worker_5fadm_5ftype_199',['WORKER_ADM_TYPE',['../worker_8h.html#acd3e6d84ae270376a9f47cfd456f7cbc',1,'worker.h']]],
  ['worker_5fdef_5ftype_200',['WORKER_DEF_TYPE',['../worker_8h.html#a19d1efe3746e4fc5c968a22b73e6fceb',1,'worker.h']]]
];
