var searchData=
[
  ['login_47',['login',['../class_user.html#a0ab5f495e1b57445d048d25b1485638d',1,'User']]],
  ['login_5funique_48',['login_unique',['../class_user.html#a8f6ff126453d87e5e6166528042194e2',1,'User']]]
];
