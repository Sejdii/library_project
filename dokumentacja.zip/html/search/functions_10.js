var searchData=
[
  ['worker_191',['Worker',['../class_worker.html#a16cae7b66b2d24d4559cad565f7345fc',1,'Worker::Worker(User user)'],['../class_worker.html#a44e0e6605fca65a4596c56a9aa308fe5',1,'Worker::Worker(int type, QString name, QString surname)'],['../class_worker.html#a99d85e89f6cc0c0364a1ade818fdce52',1,'Worker::Worker(unsigned int id)']]],
  ['workerwindow_192',['WorkerWindow',['../class_worker_window.html#a7c2732a974d963d03861f426cab1eb86',1,'WorkerWindow']]]
];
