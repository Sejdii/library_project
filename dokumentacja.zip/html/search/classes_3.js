var searchData=
[
  ['dbmanager_99',['DBManager',['../class_d_b_manager.html',1,'']]]
];
