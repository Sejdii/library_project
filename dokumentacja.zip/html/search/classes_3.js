var searchData=
[
  ['dbmanager_92',['DBManager',['../class_d_b_manager.html',1,'']]]
];
