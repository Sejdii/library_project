var searchData=
[
  ['publisher_101',['Publisher',['../class_publisher.html',1,'']]]
];
