var searchData=
[
  ['publisher_94',['Publisher',['../class_publisher.html',1,'']]]
];
