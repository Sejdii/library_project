var searchData=
[
  ['initial_5fdatabase_144',['initial_database',['../class_d_b_manager.html#a438222ec748934a278859876f60d9d4b',1,'DBManager']]],
  ['is_5fexist_145',['is_exist',['../class_book.html#a8c23111c1aee001ab9dd495847c518e8',1,'Book::is_exist()'],['../class_client.html#a0e8f399edad06ef4a0cc62af9b5cfb37',1,'Client::is_exist()']]]
];
