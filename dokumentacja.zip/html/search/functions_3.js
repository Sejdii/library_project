var searchData=
[
  ['dbmanager_127',['DBManager',['../class_d_b_manager.html#a4b82f81f5f5f4892b31c46cb0c60a766',1,'DBManager']]]
];
