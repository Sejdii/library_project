var searchData=
[
  ['book_6',['Book',['../class_book.html',1,'Book'],['../class_book.html#a6cfea0eefeafdcaa61990904151009ab',1,'Book::Book()']]],
  ['book_2eh_7',['book.h',['../book_8h.html',1,'']]]
];
