var searchData=
[
  ['mainwindow_147',['MainWindow',['../class_main_window.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow']]],
  ['make_5fconnection_5fauthor_148',['make_connection_author',['../class_book.html#a4cb26f65c22207a780fdaa1feb7c1212',1,'Book']]]
];
