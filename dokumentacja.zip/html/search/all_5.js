var searchData=
[
  ['fetch_5fby_5fid_24',['fetch_by_id',['../class_client.html#a2da7fbf407910ce7edd35277776d59a5',1,'Client']]],
  ['fetch_5fworker_5fdata_25',['fetch_worker_data',['../class_worker.html#ae961edc8dcd77712896f9b4f84450970',1,'Worker']]]
];
